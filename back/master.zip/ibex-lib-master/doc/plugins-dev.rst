
.. _ibex-plugins-dev:

***************************
Writing a plugin for Ibex
***************************

.. note::

  TODO.

For now just see the template repository for a plugin
`here <https://github.com/ibex-team/template-ibex-plugin-cmake>`_.
