/*
 * InputNodeMap.cpp
 *
 *  Created on: Mar 2, 2020
 *      Author: gilles
 */

#include <ibex_InputNodeMap.h>

namespace ibex {

//InputNodeMap::InputNodeMap() {
//	// TODO Auto-generated constructor stub
//
//}
//
//InputNodeMap::~InputNodeMap() {
//	// TODO Auto-generated destructor stub
//}
//
//
////ExprInput::ExprInput(const ExprInput& input) : args(input.args.size()), mutable_csts(input.mutable_csts.size()) {
////	for (int i=0; i<args.size(); i++) {
////		args.set_ref(i,ExprSymbol::new_(input.args[i].name, input.args[i].dim));
////	}
////
////	for (int i=0; i<mutable_csts.size(); i++) {
////		mutable_csts.set_ref(i,ExprConstant::new_mutable(input.mutable_csts[i].get()));
////	}
////}
} /* namespace ibex */
