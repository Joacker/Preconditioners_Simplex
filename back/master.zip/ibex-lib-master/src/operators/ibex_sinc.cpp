//============================================================================
//                                  I B E X
// File        : ibex_sinc.cpp
// Author      : Gilles Chabert
// Copyright   : IMT Atlantique (France)
// License     : See the LICENSE file
// Created     : Oct 02, 2018
//============================================================================

namespace ibex {

extern const char SINC[] = "sinc";

} // end namespace
